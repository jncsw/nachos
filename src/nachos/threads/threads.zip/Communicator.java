package nachos.threads;

import nachos.machine.*;

import java.util.LinkedList;

/**
 * A <i>communicator</i> allows threads to synchronously exchange 32-bit
 * messages. Multiple threads can be waiting to <i>speak</i>,
 * and multiple threads can be waiting to <i>listen</i>. But there should never
 * be a time when both a speaker and a listener are waiting, because the two
 * threads can be paired off at this point.
 */
public class Communicator {
    /**
     * Allocate a new communicator.
     */
    public Communicator() {
        lock = new Lock();
        list = new LinkedList<Integer>();
        speaker = new Condition(lock);//条件变量
        listener = new Condition(lock);//条件变量
        speakercnt = listenercnt = 0;
    }

    /**
     * Wait for a thread to listen through this communicator, and then transfer
     * <i>word</i> to the listener.
     * <p>
     * <p>
     * Does not return until this thread is paired up with a listening thread.
     * Exactly one listener should receive <i>word</i>.
     *
     * @param    word    the integer to transfer.
     */
    public void speak(int word) {
        lock.acquire();
        list.add(word);
        System.out.println("Speaker speaks : "+word);
        if(listenercnt==0){
            speakercnt++;
            speaker.sleep();
        }
        System.out.println("Speaker done");
        listener.wake();
        listenercnt--;

        lock.release();
    }

    /**
     * Wait for a thread to speak through this communicator, and then return
     * the <i>word</i> that thread passed to <tt>speak()</tt>.
     *
     * @return the integer transferred.
     */
    public int listen() {

        lock.acquire();
        if(speakercnt==0){
            listenercnt++;
            listener.sleep();
        }

        int word = list.removeFirst();
        System.out.println("listener received : "+word);
        System.out.println("waking up a speaker");
        speaker.wake();
        speakercnt--;


        lock.release();

        return 0;
    }
    //task1-4
    private LinkedList<Integer> list;
    private Lock lock;
    private Condition speaker,listener;
    private int speakercnt,listenercnt;

    //end task1-4
}
