package nachos.verify;

import nachos.threads.KThread;
import nachos.threads.ThreadedKernel;


public class TestAlarm {
    public static void TestAlarm(){
        System.out.println("***Test Alarm***");
        ThreadedKernel.alarm.waitUntil(5000);
        System.out.println("***End Test Alarm***");
    }
}
