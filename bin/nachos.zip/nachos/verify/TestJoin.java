package nachos.verify;

import nachos.threads.KThread;


public class TestJoin implements Runnable {
    TestJoin(int which) {
        this.which = which;
    }

    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println("thread " + which + " is running!");
        }
    }

    private int which;
    public static void testJoin() {
        System.out.println("***starting test Join method***");
        KThread thread2 = new KThread(new TestJoin(2));
        thread2.setName("testJoin").fork();
        System.out.println("Call join");
        thread2.join();
        new TestJoin(1).run();
        System.out.println("***end test Join method***");
    }


}


