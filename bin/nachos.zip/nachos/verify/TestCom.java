package nachos.verify;

import nachos.threads.Communicator;
import nachos.threads.KThread;

import static nachos.threads.KThread.yield;


public class TestCom {
    public static void TestCom() {
        System.out.println("***TestCom***");
        Communicator com = new Communicator();
        for(int i=0;i<5;i++){

        new KThread(new Runnable() {
            public void run() {
                    int tmp = (int)(Math.random()*100);
//                    tmp = 1001;
//                System.out.println("Speak "+tmp);

                com.speak(tmp);
            }
        }).setName("speaker").fork();
        }
        for(int i=0;i<5;i++)
        new KThread(new Runnable() {
            public void run() {
                    com.listen();
            }
        }).setName("listener").fork();
        yield();
        System.out.println("***end of Testcom***");
    }

}
