package nachos.verify;

import nachos.threads.Condition2;
import nachos.threads.KThread;
import nachos.threads.Lock;

public class TestCondition implements Runnable{
    TestCondition(){

    }

    public void run() {
        System.out.println("main thread is starting");
        lock.acquire();
        System.out.println("main thread is sleeping");
        condition2.sleep();
        System.out.println("main thread is running");
        System.out.println("main thread wake up ThreadA ");
        condition2.wake();
        lock.release();
        System.out.println("main thread finished");
        ThreadA.yield();
    }

    public static void TestCondition() {
        System.out.println("***Test Condition2***");
        ThreadA = new KThread(new Runnable() {
            public void run() {
                System.out.println("ThreadA is starting");
                lock.acquire();
                System.out.println("ThreadA is waking up the main thread");
                condition2.wake();
                System.out.println("ThreadA is running");
                System.out.println("ThreadA is sleeping");
                condition2.sleep();
                lock.release();
                System.out.println("ThreadA finished");
            }
        });
        ThreadA.setName("ThreadA").fork();
        new TestCondition().run();
        System.out.println("*** end of TestCondition ***");
    }
    private static Lock lock = new Lock();
    private static Condition2 condition2 = new Condition2(lock);
    private static KThread ThreadA = null;

}
