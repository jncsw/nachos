package nachos.verify;

import nachos.machine.Machine;
import nachos.threads.KThread;
import nachos.threads.Lock;
import nachos.threads.ThreadedKernel;

public class TestPriorityScheduler {
    public static void TestPriorityScheduler() {
        System.out.println("***testPriorityScheduler***");
        boolean intStatus = Machine.interrupt().disable();
        Lock lock = new Lock();

        KThread ThreadA = new KThread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                System.out.println("Thread A is starting");
                lock.acquire();
                System.out.println("Thread A is sleeping");
                KThread.yield();
                System.out.println("Thread A is running");
                lock.release();
                System.out.println("Thread A is finished");
            }
        });
        ThreadA.setName("A").fork();
        ThreadedKernel.scheduler.setPriority(ThreadA, 1);
        KThread.yield();//先让A运行 获得锁
        KThread ThreadB = new KThread(new Runnable() {
            @Override
            public void run() {
                // TODO Auto-generated method stub
                System.out.println("Thread B is starting");
                lock.acquire();
                System.out.println("Thread B is running");
                lock.release();
                System.out.println("Thread B is finished");
            }
        });

        ThreadB.setName("B").fork();
        ThreadedKernel.scheduler.setPriority(ThreadB, 2);
        KThread ThreadC = new KThread(new Runnable() {
            public void run() {
                // TODO Auto-generated method stub
                System.out.println("Thread C is starting");
                lock.acquire();
                System.out.println("Thread C is running");
                lock.release();
                System.out.println("Thread C is finishing");
            }
        });
        ThreadC.setName("C").fork();
        ThreadedKernel.scheduler.setPriority(ThreadC, 3);

        Machine.interrupt().restore(intStatus);
        KThread.yield();//此时让出CPU，C优先级最高



        System.out.println("*** Testjoin method***");
        intStatus = Machine.interrupt().disable();
        KThread ThreadD = new KThread(new Runnable() {
            public void run() {
                // TODO Auto-generated method stub
                System.out.println("Thread D is starting");
//                lock.acquire(); // join方法，注释
                System.out.println("Thread D is running");
//                lock.release();
                System.out.println("Thread D is finishing");
            }
        });
        ThreadD.setName("D").fork();
        ThreadedKernel.scheduler.setPriority(ThreadD, 1);

        KThread ThreadE = new KThread(new Runnable() {
            public void run() {
                // TODO Auto-generated method stub
                System.out.println("Thread E is starting");
//                lock.acquire();
                System.out.println("Thread E is running");
//                lock.release();
                System.out.println("Thread E is finishing");
            }
        });
        ThreadE.setName("E").fork();
        ThreadedKernel.scheduler.setPriority(ThreadE, 2);

        KThread ThreadF = new KThread(new Runnable() {
            public void run() {
                // TODO Auto-generated method stub
                System.out.println("Thread F is starting");
                System.out.println("Thread D call join");
                ThreadD.join();
                System.out.println("Thread F is finishing");
            }
        });
        ThreadF.setName("F").fork();
        ThreadedKernel.scheduler.setPriority(ThreadF, 3);
        Machine.interrupt().restore(intStatus);
        KThread.yield();
        System.out.println("*** end of TestPriorityScheduler method ***");
    }

}
